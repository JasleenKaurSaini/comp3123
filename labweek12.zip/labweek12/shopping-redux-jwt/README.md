This application combines React, Redux, and JWT concepts in a small shopping cart demo.

1. Redux Setup

cartSlice.js creates:
 - initialState → stores cart items
 - reducers → addToCart and removeFromCart
 - actions → used to update the state

store.js:
 - Creates the Redux store
 - Connects the cart reducer to the app

2. JWT Login Logic

 - When the user clicks Login, a fake token (fake.jwt.token123) is 
   saved to localStorage.
 - If the token exists → user is considered logged in.
 - Clicking Logout removes the token and returns to login screen.

3. App.js (All UI in one file)

App.js contains three small views:

a) Login View
 - Appears when no JWT token is found.
 - Clicking login sets a fake JWT and updates logged-in state.

b) Shop View
 - Displays a list of products.
 - Clicking Add dispatches addToCart(item) to Redux.

c) Cart View
 - Shows all added cart items using useSelector.
 - Clicking Remove dispatches removeFromCart(id).
 - Logout clears JWT token.

4. React + Redux Interaction
 
 - useDispatch() → sends actions to Redux
 - useSelector() → automatically subscribes to the Redux store
 - UI updates instantly when Redux state changes