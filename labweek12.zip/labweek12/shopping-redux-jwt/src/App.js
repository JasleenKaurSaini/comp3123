import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addToCart, removeFromCart } from "./redux/cartSlice";

function App() {
  // Check if user is logged in using JWT
  const [loggedIn, setLoggedIn] = useState(!!localStorage.getItem("token"));
  const [view, setView] = useState("shop"); // "shop" or "cart"

  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);

  // Fake login (stores a token)
  const handleLogin = () => {
    localStorage.setItem("token", "fake.jwt.token123");
    setLoggedIn(true);
  };

  // Fake logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    setLoggedIn(false);
  };

  // If logged out → show login view only
  if (!loggedIn) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Login</h2>
        <button onClick={handleLogin}>Click to Login</button>
      </div>
    );
  }

  const products = [
    { id: 1, name: "Perfume", price: 25 },
    { id: 2, name: "Body Lotion", price: 15 },
    { id: 3, name: "Shampoo", price: 18 }
  ];

  return (
    <div style={{ padding: 20 }}>
      {/* Navigation Buttons */}
      <button onClick={() => setView("shop")}>Shop</button>
      <button onClick={() => setView("cart")} style={{ marginLeft: 10 }}>
        Cart ({cartItems.length})
      </button>
      <button onClick={handleLogout} style={{ marginLeft: 10 }}>
        Logout
      </button>

      {/* ---------------- SHOP VIEW ---------------- */}
      {view === "shop" && (
        <div style={{ marginTop: 20 }}>
          <h2>Products</h2>
          {products.map((item) => (
            <div key={item.id} style={{ marginBottom: 10 }}>
              {item.name} - ${item.price}
              <button
                onClick={() => dispatch(addToCart(item))}
                style={{ marginLeft: 10 }}
              >
                Add
              </button>
            </div>
          ))}
        </div>
      )}

      {/* ---------------- CART VIEW ---------------- */}
      {view === "cart" && (
        <div style={{ marginTop: 20 }}>
          <h2>Your Cart</h2>

          {cartItems.length === 0 ? (
            <p>No items added yet.</p>
          ) : (
            cartItems.map((item) => (
              <div key={item.id} style={{ marginBottom: 10 }}>
                {item.name} - ${item.price}
                <button
                  onClick={() => dispatch(removeFromCart(item.id))}
                  style={{ marginLeft: 10 }}
                >
                  Remove
                </button>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default App;
