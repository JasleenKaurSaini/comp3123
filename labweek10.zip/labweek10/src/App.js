import { useState } from "react";
import "./App.css";

export default function App() {
  const [formData, setFormData] = useState({
    email: "",
    fullName: "",
    address: "",
    address2: "",
    city: "",
    province: "",
    postalCode: "",
    agree: false,
  });

  const [submitted, setSubmitted] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted({ ...formData });
  };

  return (
    <div className="app">
      <h1>Data Entry Form</h1>

      <form className="entry-form" onSubmit={handleSubmit}>
        <div className="row">
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              name="email"
              placeholder="Enter email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="field">
            <label htmlFor="fullName">Full Name</label>
            <input
              id="fullName"
              type="text"
              name="fullName"
              placeholder="Full Name"
              value={formData.fullName}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <div className="field">
          <label htmlFor="address">Address</label>
          <input
            id="address"
            type="text"
            name="address"
            placeholder="160 Kendal Ave"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </div>

        <div className="row">
          <div className="field">
            <label htmlFor="city">City</label>
            <input
              id="city"
              type="text"
              name="city"
              value={formData.city}
              onChange={handleChange}
              required
            />
          </div>

          <div className="field">
            <label htmlFor="province">Province</label>
            <select
              id="province"
              name="province"
              value={formData.province}
              onChange={handleChange}
              required
            >
              <option value="" disabled>
                Choose...
              </option>
              <option value="Ontario">Ontario</option>
              <option value="Quebec">Quebec</option>
              <option value="British Columbia">British Columbia</option>
              <option value="Alberta">Alberta</option>
              <option value="Manitoba">Manitoba</option>
            </select>
          </div>

          <div className="field">
            <label htmlFor="postalCode">Postal Code</label>
            <input
              id="postalCode"
              type="text"
              name="postalCode"
              value={formData.postalCode}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <div className="checkbox-container">
          <input
            id="agree"
            type="checkbox"
            name="agree"
            checked={formData.agree}
            onChange={handleChange}
            required
          />
          <label htmlFor="agree">Agree Terms &amp; Condition?</label>
        </div>

        <button type="submit">Submit</button>
      </form>

      {submitted && (
        <div className="submitted">
          <dl className="kv">
            <dt>Email</dt>
            <dd>{submitted.email}</dd>

            <dt>Full Name</dt>
            <dd>{submitted.fullName}</dd>

            <dt>Address</dt>
            <dd>{submitted.address}</dd>

            <div className="row-inline">
              <dt>City</dt>
              <dd>{submitted.city}</dd>
              <dt>Province</dt>
              <dd>{submitted.province}</dd>
              <dt>Postal Code</dt>
              <dd>{submitted.postalCode}</dd>
            </div>
          </dl>
        </div>
      )}
    </div>
  );
}
